def square(number):
    print(number * number)
    return number * number

square(69)
