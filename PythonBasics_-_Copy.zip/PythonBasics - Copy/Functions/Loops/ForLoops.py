items = range(1,10)
for item in items:
    print(item)