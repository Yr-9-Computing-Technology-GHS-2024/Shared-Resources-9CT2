range = range(0, 1000, 1)
for i in range:
  print (i)