for x in range(4):
    for y in range(3):
        print(f'({x},{y})')
        