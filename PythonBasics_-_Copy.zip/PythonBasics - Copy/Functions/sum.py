print ("hello i am a calculator")
in_1 = input ("input any number: ")
float1 = float (in_1)
in_2 = input ("input any number: ")
float2 = float (in_2)
ans = float1 + float2
print ("Sum: " + str(ans))