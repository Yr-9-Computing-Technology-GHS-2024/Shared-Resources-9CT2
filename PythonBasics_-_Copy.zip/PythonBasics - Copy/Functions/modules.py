import converters
import MaxNumbers
# import Programs.weightCalculator

numbers = [7,6,5,4,5]
MaxNumbers.find_max_number()
converters.lbs_to_kg()
converters.kg_to_lbs()