def function():
    print("I am a function")

function()