name = input("what is your name? ")
print ("hello " + name)