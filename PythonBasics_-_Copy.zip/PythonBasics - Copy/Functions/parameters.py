def example(first_name,last_name):
    print(f"Hi {first_name} {last_name}")
#Positional arguments first
example(first_name="Cursed",last_name="Toxic")