import random
random = random.randint (1, 6)
print (random)
if random <= 4:
  print ("he will score")

