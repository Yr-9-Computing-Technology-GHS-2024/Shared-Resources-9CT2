class Example:
    def __init__(self,x,y):
        self.x = x
        self.y = y

    def move():
        print("MOVE")
    
    def draw():
        print("DRAW")

example1 = Example(1,2)
print(example1.x)
