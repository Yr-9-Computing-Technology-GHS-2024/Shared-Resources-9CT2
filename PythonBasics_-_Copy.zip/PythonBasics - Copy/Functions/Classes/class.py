class example:
    def move():
        print("MOVE")
    
    def draw():
        print("DRAW")

example1 = example
example1.draw()
    