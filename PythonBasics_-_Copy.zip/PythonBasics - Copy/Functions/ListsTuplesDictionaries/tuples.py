numbers = (1,2,3)
print(numbers[0])
# Tuples cannot be changed.
