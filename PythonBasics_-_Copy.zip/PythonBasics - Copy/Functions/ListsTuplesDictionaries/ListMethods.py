numbers = [1,2,3,4,5,6,7,8,9,0]
numbers.append(1) # adds item at the end
numbers.insert(1,10) # inserts items at given position
numbers2 = numbers.copy() #copies the list
# numbers.reverse - reverses list
# numbers.sort - sorted in order
# numbers.count - count how many of a certain number in list
# numbers.index - check for existence of item in list
# numbers.pop - removes last item from list
# numbers.remove - removes items of list
# numbers.clear - clear whole list
# (x in numbers) - check if this exists