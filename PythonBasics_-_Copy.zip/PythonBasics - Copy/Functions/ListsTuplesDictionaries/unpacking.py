coordinates = (1,2,3)
x,y,z = coordinates
# Can be done with lists too