numbers = [1,6,2,5,3,4]
max = numbers[0]
for number in numbers:
    if number > max:
        max = number 
print(number)